
/**
 * Write a description of class Seed here.
 *
 * @author (conor hayes)
 * @version (October 25th 2017)
 */
public class Seed extends Vegetable
{
    // instance variables - replace the example below with your own
    int calories;
    

    /**
     * Constructor for objects of class Seed
     */
    public Seed()
    {
        calories = 10;
    }
    
    
    @Override
    public int getCalories(){
        return calories;
    }
    
    /**
     * returns the current value for Calories
     * and then sets the calory value to zero
     * i.e. the energy has been extracted from Seed
     */
    @Override
    public int extractEnergy(){
       //TODO
       return 0;
    }
    
}
