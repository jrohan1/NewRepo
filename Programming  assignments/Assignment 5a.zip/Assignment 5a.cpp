// Assignment 5a.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>

void main()
{
	int age = 0;
	float average;
	int min = 0;
	int max = 0;
	int exit = 0;
	int ages[10];
	int input = 0;
	int sum = 0;


	printf("Program to calculate average of up to 10 ages\n");

	printf("Enter up to 10 ages <-1 to end input>\n__________________________\n");

	do
	{
		printf("#%d:\t", input + 1);

		scanf_s("%d", &ages[input]);

		if (ages[input] != -1)
		{
			sum = sum + ages[input];
			input = input + 1;
		}
		else
		{
			break;
		}
	} while (input <10);

	average = sum / input;
	printf("Average:  %.2f\n", average);

	int j = 0;
	min = ages[0];
	max = ages[0];
	while (j<input)
	{
		if (ages[j] < min)
			min = ages[j];
		j++;
	}

	while (j<input)
	{
		if (ages[j] > max)
			max = ages[j];
		j++;
	}
	printf("Min: %d\n", min);
	printf("Max: %d\n", max);

}


